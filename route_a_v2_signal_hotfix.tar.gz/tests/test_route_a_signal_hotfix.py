from scripts.appworld_azure_continuation_worker import _next_action
from scripts.train_route_a_preference import balanced_causal_epoch_order


class FakeClient:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = 0

    def complete(self, messages, max_tokens=500, temperature=0.0):
        self.calls += 1
        return next(self.responses)


def request():
    return {
        "instruction": "Do the visible task",
        "event_context": {},
        "tool_schemas": [],
        "history": [],
        "remaining_steps": 3,
    }


def test_continuation_repairs_invalid_json_once():
    client = FakeClient(
        [
            "I would call the tool, but this is not JSON",
            '```json\n{"tool":"notes__create","arguments":{"text":"x"}}\n```',
        ]
    )
    result = _next_action(client, request())
    assert result["action"] == {
        "tool": "notes__create",
        "arguments": {"text": "x"},
    }
    assert result["format_repair_attempted"] is True
    assert client.calls == 2


def test_continuation_never_fabricates_default_after_failed_repair():
    client = FakeClient(["not json", '{"tool":"bad","arguments":[]}'])
    result = _next_action(client, request())
    assert result == {
        "action": None,
        "error_type": "invalid_action_shape",
        "format_repair_attempted": True,
    }


def test_v2_epoch_is_balanced_and_budget_matched():
    rows = []
    for index in range(9):
        rows.append({"event_id": f"r{index}", "decision": "rescue_preference"})
    for index in range(15):
        rows.append({"event_id": f"v{index}", "decision": "reverse_preference"})
    for index in range(62):
        rows.append({"event_id": f"z{index}", "decision": "zero_delta"})

    ordered = balanced_causal_epoch_order(rows, 42, 0, len(rows))
    assert len(ordered) == 86
    assert sum(row["decision"] == "rescue_preference" for row in ordered) == 43
    assert sum(row["decision"] == "reverse_preference" for row in ordered) == 43
    assert not any(row["decision"] == "zero_delta" for row in ordered)
    assert ordered == balanced_causal_epoch_order(rows, 42, 0, len(rows))
