import inspect
import json

from environments.api_bank import (
    DeployableAPIBankHarness,
    OracleAPIBankHarness,
    VisibleContextSemanticValidator,
    public_harness_observation,
)


OBSERVATION = {
    "task_id": "hidden-task-id",
    "user_goal": 'My username is "admin" and the password is adminpass.',
    "available_tools": [
        {"name": "GetUserToken", "required": ["username", "password"], "optional": []},
    ],
    "call_index": 0,
    "num_reference_actions": 99,
    "success_predicate_satisfied": False,
    "state_hash": "visible-state",
    "reference_actions": [
        {"tool": "SECRET_REFERENCE_TOOL", "arguments": {"secret": "DO_NOT_LEAK"}},
    ],
}


def test_deployable_api_cannot_receive_expected_action():
    inspect_parameters = inspect.signature(DeployableAPIBankHarness.inspect).parameters
    execute_parameters = inspect.signature(DeployableAPIBankHarness.execute).parameters
    assert "expected" not in inspect_parameters and "reference_actions" not in inspect_parameters
    assert "expected" not in execute_parameters and "reference_actions" not in execute_parameters


def test_public_observation_removes_reference_fields_and_values():
    public = public_harness_observation(OBSERVATION)
    payload = json.dumps(public, sort_keys=True)
    assert "reference" not in payload.lower()
    assert "SECRET_REFERENCE_TOOL" not in payload
    assert "DO_NOT_LEAK" not in payload
    assert "num_reference_actions" not in public


def test_visible_context_validator_is_tri_state_not_schema_equals_semantics():
    validator = VisibleContextSemanticValidator()
    supported = {
        "tool": "GetUserToken",
        "arguments": {"username": "admin", "password": "adminpass"},
    }
    contradicted = {
        "tool": "GetUserToken",
        "arguments": {"username": "mallory", "password": "adminpass"},
    }
    unknown = {
        "tool": "GetUserToken",
        "arguments": {"username": "admin", "password": "runtime-secret"},
    }
    assert validator.validate(OBSERVATION, supported).semantic_valid == "true"
    assert validator.validate(OBSERVATION, contradicted).semantic_valid == "false"
    assert validator.validate(OBSERVATION, unknown).semantic_valid in {"false", "unknown"}


def test_deployable_harness_repairs_only_from_visible_goal():
    proposal = {"tool": "GetUserToken", "arguments": {"username": "admin"}}
    executed, decision = DeployableAPIBankHarness("H3").execute(OBSERVATION, proposal)
    assert decision.changes_execution
    assert decision.patch_id == "visible_schema_repair"
    assert executed == {
        "tool": "GetUserToken",
        "arguments": {"username": "admin", "password": "adminpass"},
    }


def test_deployable_harness_skips_when_visible_context_is_insufficient():
    observation = {
        "user_goal": "Please authenticate me.",
        "available_tools": [
            {"name": "GetUserToken", "required": ["username", "password"], "optional": []},
        ],
        "success_predicate_satisfied": False,
    }
    proposal = {"tool": "GetUserToken", "arguments": {"username": "admin"}}
    executed, decision = DeployableAPIBankHarness("H3").execute(observation, proposal)
    assert executed == proposal
    assert decision.corrected_action is None
    assert not decision.changes_execution


def test_oracle_harness_remains_explicit_upper_bound():
    expected = {"tool": "GetUserToken", "arguments": {"username": "admin", "password": "adminpass"}}
    proposal = {"tool": "Other", "arguments": {}}
    executed, decision = OracleAPIBankHarness("H3").execute(OBSERVATION, proposal, expected)
    assert decision.changes_execution and executed == expected


def test_frozen_generator_can_only_supply_visible_missing_values():
    observation = {
        "user_goal": 'Authenticate using "admin" and "p@ssw0rd".',
        "available_tools": [
            {"name": "GetUserToken", "required": ["username", "password"], "optional": []},
        ],
        "success_predicate_satisfied": False,
    }
    seen = {}

    def generator(public, proposal, reason, receipt):
        seen.update(public)
        return {
            "tool": "GetUserToken",
            "arguments": {"username": "admin", "password": "p@ssw0rd"},
        }

    proposal = {"tool": "GetUserToken", "arguments": {"username": "admin"}}
    executed, decision = DeployableAPIBankHarness("H3", correction_generator=generator).execute(
        observation, proposal
    )
    assert decision.patch_id == "generated_visible_schema_repair"
    assert decision.changes_execution
    assert executed["arguments"]["password"] == "p@ssw0rd"
    assert "reference_actions" not in seen


def test_generated_value_not_visible_in_context_is_rejected():
    observation = {
        "user_goal": 'Authenticate using "admin".',
        "available_tools": [
            {"name": "GetUserToken", "required": ["username", "password"], "optional": []},
        ],
        "success_predicate_satisfied": False,
    }

    def generator(_public, _proposal, _reason, _receipt):
        return {
            "tool": "GetUserToken",
            "arguments": {"username": "admin", "password": "invented-secret"},
        }

    proposal = {"tool": "GetUserToken", "arguments": {"username": "admin"}}
    executed, decision = DeployableAPIBankHarness("H3", correction_generator=generator).execute(
        observation, proposal
    )
    assert executed == proposal
    assert decision.corrected_action is None
    assert not decision.changes_execution
